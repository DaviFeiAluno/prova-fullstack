const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const app = express();

// =============================================
// CONFIGURAÇÃO — só mude aqui na prova
// =============================================
const uri = 'SUA_STRING_DE_CONEXAO_ATLAS';
const NOME_BANCO = 'prova';
const COLECAO = 'itens'; // ex: carros, livros, produtos
// =============================================

const client = new MongoClient(uri, { useUnifiedTopology: true });
let db;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

async function main() {
  await client.connect();
  db = client.db(NOME_BANCO);
  app.listen(80, () => console.log('Servidor rodando em http://localhost'));
}
main();

// =============================================
// ROTAS
// =============================================

// Redireciona '/' para listagem
app.get('/', (req, res) => res.redirect('/index'));

// READ — listagem
app.get('/index', async (req, res) => {
  const itens = await db.collection(COLECAO).find().toArray();
  res.render('index', { itens });
});

// Página de gerência
app.get('/gerencia', async (req, res) => {
  const itens = await db.collection(COLECAO).find().toArray();
  res.render('gerencia', { itens });
});

// CREATE — cadastrar item
app.post('/cadastrar', async (req, res) => {
  const { campo1, campo2, campo3, qtde } = req.body;
  await db.collection(COLECAO).insertOne({
    campo1,
    campo2,
    campo3,
    qtde_disponivel: parseInt(qtde)
  });
  res.redirect('/gerencia');
});

// UPDATE — atualizar item
app.post('/atualizar', async (req, res) => {
  const { id, campo1, campo2, campo3, qtde } = req.body;
  await db.collection(COLECAO).updateOne(
    { _id: new ObjectId(id) },
    { $set: { campo1, campo2, campo3, qtde_disponivel: parseInt(qtde) } }
  );
  res.redirect('/gerencia');
});

// DELETE — remover item
app.post('/remover', async (req, res) => {
  await db.collection(COLECAO).deleteOne({ _id: new ObjectId(req.body.id) });
  res.redirect('/gerencia');
});

// UPDATE — vender/decrementar quantidade
app.post('/vender', async (req, res) => {
  const item = await db.collection(COLECAO).findOne({ _id: new ObjectId(req.body.id) });
  if (item.qtde_disponivel > 0) {
    await db.collection(COLECAO).updateOne(
      { _id: new ObjectId(req.body.id) },
      { $inc: { qtde_disponivel: -1 } }
    );
  }
  res.redirect('/gerencia');
});

// =============================================
// USUÁRIOS
// =============================================

app.get('/cadastro', (req, res) => res.render('cadastro'));
app.post('/cadastro', async (req, res) => {
  const { nome, login, senha } = req.body;
  await db.collection('usuarios').insertOne({ nome, login, senha });
  res.redirect('/login');
});

app.get('/login', (req, res) => res.render('login'));
app.post('/login', async (req, res) => {
  const { login, senha } = req.body;
  const user = await db.collection('usuarios').findOne({ login, senha });
  if (user) res.redirect('/gerencia');
  else res.send('Login inválido. <a href="/login">Voltar</a>');
});
