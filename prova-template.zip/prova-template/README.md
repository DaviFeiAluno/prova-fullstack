# Template Prova — Node + MongoDB + EJS

## Setup rápido (CMD como Administrador)

```
npm install
node server.js
```

Acesse: http://localhost

---

## O que adaptar na prova

### 1. server.js — topo do arquivo
```js
const uri = 'SUA_STRING_DE_CONEXAO_ATLAS';
const NOME_BANCO = 'prova';       // nome do banco
const COLECAO = 'itens';          // ex: carros, livros, produtos
```

### 2. Renomear campos nas views
- Troque `campo1`, `campo2`, `campo3` pelos campos reais
- Ex: marca, modelo, ano para carros

### 3. Renomear campos no server.js
- No `insertOne` e `updateOne`, troque campo1/campo2/campo3 pelos nomes reais

---

## Rotas disponíveis

| Rota | Método | O que faz |
|------|--------|-----------|
| `/` | GET | Redireciona para /index |
| `/index` | GET | Lista todos os itens |
| `/gerencia` | GET | Página de CRUD |
| `/cadastrar` | POST | Cria novo item |
| `/atualizar` | POST | Atualiza item |
| `/remover` | POST | Remove item |
| `/vender` | POST | Decrementa qtde |
| `/cadastro` | GET/POST | Cadastro de usuário |
| `/login` | GET/POST | Login de usuário |

---

## As 4 operações do MongoDB

```js
// CREATE
await db.collection('nome').insertOne({ campo: valor });

// READ
await db.collection('nome').find().toArray();

// UPDATE
await db.collection('nome').updateOne(
  { _id: new ObjectId(id) },
  { $set: { campo: valor } }
);

// DELETE
await db.collection('nome').deleteOne({ _id: new ObjectId(id) });
```
