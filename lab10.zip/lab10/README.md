# 📋 README — Prova Node + MongoDB

---

## ⚡ Rodar o projeto (fazendo isso já garante pontos)

### 1. Abrir CMD como Administrador
- Windows → digita `cmd` → botão direito → **Executar como administrador**

### 2. Navegar até a pasta
```cmd
cd C:\caminho\da\pasta
```

### 3. Instalar dependências
```cmd
npm install mongodb@4.12 express ejs
```

### 4. Colocar a string do Atlas no server.js
```js
const uri = 'mongodb+srv://DaviRamos01:SUA_SENHA@daviramos01.3onyrqa.mongodb.net/?appName=DaviRamos01';
```

### 5. Rodar
```cmd
node server.js
```

### 6. Abrir no navegador
```
http://localhost
```

---

## 🔌 Se não conectar no Atlas

Vai no site do Atlas → **Network Access** → **Add IP Address** → **Allow Access from Anywhere** → Confirm

---

## 📁 Estrutura do projeto

```
lab/
├── server.js
├── package.json
├── public/
│   └── style.css
└── views/
    ├── carros.ejs     ← listagem (READ)
    ├── gerencia.ejs   ← cadastrar, atualizar, remover, vender
    ├── cadastro.ejs   ← cadastro de usuário
    └── login.ejs      ← login de usuário
```

---

## 🗺️ Rotas do servidor

| Rota | Método | O que faz |
|---|---|---|
| `/` | GET | Redireciona para /carros |
| `/carros` | GET | Lista todos os carros |
| `/gerencia` | GET | Página de gerência |
| `/carros/cadastrar` | POST | Cria novo carro |
| `/carros/atualizar` | POST | Atualiza carro |
| `/carros/remover` | POST | Remove carro |
| `/carros/vender` | POST | Decrementa quantidade |
| `/cadastro` | GET/POST | Cadastro de usuário |
| `/login` | GET/POST | Login de usuário |

---

## 🧠 As 4 operações do MongoDB — decorar isso

```js
// CREATE
await db.collection('carros').insertOne({ marca, modelo, ano, qtde_disponivel });

// READ
await db.collection('carros').find().toArray();

// UPDATE
await db.collection('carros').updateOne(
  { _id: new ObjectId(id) },
  { $set: { marca, modelo, ano, qtde_disponivel } }
);

// DELETE
await db.collection('carros').deleteOne({ _id: new ObjectId(id) });

// UPDATE com decremento (vender)
await db.collection('carros').updateOne(
  { _id: new ObjectId(id) },
  { $inc: { qtde_disponivel: -1 } }
);
```

---

## 🗄️ Coleções no banco

**carros**
```json
{
  "marca": "VW",
  "modelo": "Gol",
  "ano": 2020,
  "qtde_disponivel": 5
}
```

**usuarios**
```json
{
  "nome": "Davi",
  "login": "davi",
  "senha": "123"
}
```

---

## ✅ Checklist antes de entregar

- [ ] `node server.js` rodou sem erro no CMD
- [ ] `http://localhost` abriu no navegador
- [ ] Cadastrei um carro → apareceu na listagem
- [ ] Atualizei um carro → mudou no banco
- [ ] Removi um carro → sumiu da listagem
- [ ] Vendi um carro → quantidade diminuiu
- [ ] Quantidade zero → aparece "Esgotado"
- [ ] Cadastrei um usuário → foi pro banco
- [ ] Login correto → entrou na gerência
- [ ] Login errado → mostrou mensagem de erro

---

## 🔴 Erros comuns

| Erro | Solução |
|---|---|
| Porta 80 negada | CMD como Administrador |
| `Cannot find module` | `npm install mongodb@4.12 express ejs` |
| Não conecta no Atlas | Liberar IP no Network Access |
| `<db_password>` na URI | Trocar pela senha real |
| Página em branco | Ver mensagem de erro no CMD |
| `ObjectId` inválido | Checar `value="<%= c._id %>"` no EJS |
