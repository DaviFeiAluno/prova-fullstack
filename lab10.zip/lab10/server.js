const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const app = express();

const uri = 'SUA_STRING_DE_CONEXAO_ATLAS';
const client = new MongoClient(uri, { useUnifiedTopology: true });
let db;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

async function main() {
  await client.connect();
  db = client.db('lab10');
  app.listen(80, () => console.log('Servidor rodando em http://localhost'));
}
main();

// Redireciona '/' para listagem
app.get('/', (req, res) => res.redirect('/carros'));

// READ — listagem de carros
app.get('/carros', async (req, res) => {
  const carros = await db.collection('carros').find().toArray();
  res.render('carros', { carros });
});

// Página de gerência
app.get('/gerencia', async (req, res) => {
  const carros = await db.collection('carros').find().toArray();
  res.render('gerencia', { carros });
});

// CREATE — cadastrar carro
app.post('/carros/cadastrar', async (req, res) => {
  const { marca, modelo, ano, qtde } = req.body;
  await db.collection('carros').insertOne({
    marca,
    modelo,
    ano: parseInt(ano),
    qtde_disponivel: parseInt(qtde)
  });
  res.redirect('/gerencia');
});

// UPDATE — atualizar carro
app.post('/carros/atualizar', async (req, res) => {
  const { id, marca, modelo, ano, qtde } = req.body;
  await db.collection('carros').updateOne(
    { _id: new ObjectId(id) },
    { $set: { marca, modelo, ano: parseInt(ano), qtde_disponivel: parseInt(qtde) } }
  );
  res.redirect('/gerencia');
});

// DELETE — remover carro
app.post('/carros/remover', async (req, res) => {
  await db.collection('carros').deleteOne({ _id: new ObjectId(req.body.id) });
  res.redirect('/gerencia');
});

// UPDATE — vender (decrementa quantidade)
app.post('/carros/vender', async (req, res) => {
  const carro = await db.collection('carros').findOne({ _id: new ObjectId(req.body.id) });
  if (carro.qtde_disponivel > 0) {
    await db.collection('carros').updateOne(
      { _id: new ObjectId(req.body.id) },
      { $inc: { qtde_disponivel: -1 } }
    );
  }
  res.redirect('/gerencia');
});

// Cadastro de usuário
app.get('/cadastro', (req, res) => res.render('cadastro'));
app.post('/cadastro', async (req, res) => {
  const { nome, login, senha } = req.body;
  await db.collection('usuarios').insertOne({ nome, login, senha });
  res.redirect('/login');
});

// Login
app.get('/login', (req, res) => res.render('login'));
app.post('/login', async (req, res) => {
  const { login, senha } = req.body;
  const user = await db.collection('usuarios').findOne({ login, senha });
  if (user) res.redirect('/gerencia');
  else res.send('Login inválido. <a href="/login">Voltar</a>');
});
